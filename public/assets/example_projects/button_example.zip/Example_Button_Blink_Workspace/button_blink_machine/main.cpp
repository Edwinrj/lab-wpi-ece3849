#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "button.h"
#include "pins.h"

// LEDs on PN0 and PN1
#define LED_PORT_BASE GPIO_PORTN_BASE
#define LED1_PIN      GPIO_PIN_0
#define LED2_PIN      GPIO_PIN_1

// Functions to control the LEDs
static inline void ledOn(uint8_t pin) { GPIOPinWrite(LED_PORT_BASE, pin, pin); }
static inline void ledOff(uint8_t pin){ GPIOPinWrite(LED_PORT_BASE, pin, 0); }
static inline void ledToggle(uint8_t pin){
    uint32_t v = GPIOPinRead(LED_PORT_BASE, pin);
    GPIOPinWrite(LED_PORT_BASE, pin, (v & pin) ? 0 : pin);
}

// Button with OneButton-style API
static Button btn(USR_SW1);

// Callback when button is pressed
static void onPress() { ledOn(LED1_PIN); }
static void onClick() {
    // Single click: turn off LED1 and LED2
    ledOff(LED1_PIN);
    ledOff(LED2_PIN);
}
static void onDoubleClick() {
    // Double click: turn on LED2
    ledOn(LED2_PIN);
}
static void onLongPressStart() { 
    // When long press starts, turn on both LEDs
    ledOn(LED1_PIN); 
    ledOn(LED2_PIN); 
}
static void onLongPressStop()  { 
    // When long press stops, turn off both LEDs
    ledOff(LED1_PIN); 
    ledOff(LED2_PIN); 
}

int main(void) {
    // Set up system clock to 120 MHz
    uint32_t gSystemClock = SysCtlClockFreqSet(
        SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN | SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480,
        120000000);

    // Initialize GPIO for LEDs
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPION);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPION));
    GPIOPinTypeGPIOOutput(LED_PORT_BASE, LED1_PIN | LED2_PIN);

    // Initialize the button (enable port clock and configure pad) after MCU clock setup
    btn.begin();

    // Timing settings (optional): tick ~20 ms
    btn.setTickIntervalMs(20);
    btn.setDebounceMs(50);
    btn.setClickMs(200);  // window for single/double click
    btn.setPressMs(800);  // long-press threshold

    // Register OneButton-style callbacks
    btn.attachPress(onPress);
    btn.attachClick(onClick);
    btn.attachDoubleClick(onDoubleClick);
    btn.attachLongPressStart(onLongPressStart);
    btn.attachLongPressStop(onLongPressStop);

    // Main loop: check button state and update LEDs
    while(1){
        btn.tick();
        SysCtlDelay(gSystemClock / 3 / 50); // ~20 ms
    }
}
