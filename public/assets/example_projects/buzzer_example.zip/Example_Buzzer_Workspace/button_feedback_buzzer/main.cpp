/**
 * ============================================================================
 *  Button_Buzzer_Callback.cpp
 *  Demo: Beep on button press and release using callbacks
 *
 *  Hardware:
 *   - EK-TM4C1294XL LaunchPad
 *   - Button S1 (PA7)
 *   - Buzzer on PF1 (PWM0)
 *
 *  Author: Edwin R.
 *  Date: 2025
 * ============================================================================
 */

#include <stdint.h>
#include <stdbool.h>

extern "C" {
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/pwm.h"
#include "driverlib/pin_map.h"
#include "driverlib/gpio.h"
#include "driverlib/fpu.h"

#include "driverlib/interrupt.h"
#include "driverlib/timer.h"
#include "inc/hw_ints.h"

}

#include "button.h"
#include "timerLib.h"
#include "elapsedTime.h"

// ============================================================================
// Globals
// ============================================================================
uint32_t gSysClk;
Timer timer;
Button btnS1(S1);

// ============================================================================
// Buzzer (PF1 → M0PWM1)
// ============================================================================
#define BUZZER_PWM_BASE    PWM0_BASE
#define BUZZER_GEN         PWM_GEN_0
#define BUZZER_OUTNUM      PWM_OUT_1
#define BUZZER_OUTBIT      PWM_OUT_1_BIT

static void Buzzer_Init(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
    while (!SysCtlPeripheralReady(SYSCTL_PERIPH_PWM0));
    while (!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOF));

    GPIOPinConfigure(GPIO_PF1_M0PWM1);
    GPIOPinTypePWM(GPIO_PORTF_BASE, GPIO_PIN_1);
    PWMClockSet(PWM0_BASE, PWM_SYSCLK_DIV_64);
}

void Timer1A_Handler(void)
{
    // Clear interrupt flag
    TimerIntClear(TIMER1_BASE, TIMER_TIMA_TIMEOUT);

    // Disable PWM output
    PWMOutputState(BUZZER_PWM_BASE, BUZZER_OUTBIT, false);

    // Stop Timer1A
    TimerDisable(TIMER1_BASE, TIMER_A);
}

void Buzzer_Beep(uint32_t freq_hz, uint32_t duration_ms)
{
    if (freq_hz == 0) return;

    uint32_t pwmClock = gSysClk / 64;
    uint32_t period = pwmClock / freq_hz;

    // Configure PWM output (PF1 → M0PWM1)
    PWMGenConfigure(BUZZER_PWM_BASE, BUZZER_GEN,
                    PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC);
    PWMGenPeriodSet(BUZZER_PWM_BASE, BUZZER_GEN, period);
    PWMPulseWidthSet(BUZZER_PWM_BASE, BUZZER_OUTNUM, period / 2);
    PWMOutputState(BUZZER_PWM_BASE, BUZZER_OUTBIT, true);
    PWMGenEnable(BUZZER_PWM_BASE, BUZZER_GEN);

    // Enable Timer1 peripheral
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER1);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_TIMER1));

    // Configure Timer1A as one-shot
    TimerDisable(TIMER1_BASE, TIMER_A);
    TimerConfigure(TIMER1_BASE, TIMER_CFG_ONE_SHOT);
    TimerLoadSet(TIMER1_BASE, TIMER_A, (gSysClk / 1000) * duration_ms);

    // Register ISR and enable interrupt
    IntDisable(INT_TIMER1A);
    IntRegister(INT_TIMER1A, Timer1A_Handler);
    TimerIntClear(TIMER1_BASE, TIMER_TIMA_TIMEOUT);
    TimerIntEnable(TIMER1_BASE, TIMER_TIMA_TIMEOUT);
    IntEnable(INT_TIMER1A);

    // Start timer
    TimerEnable(TIMER1_BASE, TIMER_A);
}
// ============================================================================
// Button Callbacks
// ============================================================================
static void onClick()
{
    Buzzer_Beep(500, 60);   // Grave al presionar
}

static void onDoubleClick()
{
    Buzzer_Beep(1000, 60);  // Agudo al soltar
}

// ============================================================================
// Button initialization
// ============================================================================
static void setupButtons()
{
    btnS1.begin();
    btnS1.setDebounceMs(15);
    btnS1.setTickIntervalMs(20);
    btnS1.setClickMs(120);
    btnS1.attachClick(&onClick);
    btnS1.attachDoubleClick(&onDoubleClick);
}

// ============================================================================
// Main
// ============================================================================
int main(void)
{
    FPUEnable();
    FPULazyStackingEnable();
    gSysClk = SysCtlClockFreqSet(
        SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN |
        SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480,
        120000000
    );

    timer.begin(gSysClk, TIMER0_BASE);
    elapsedMillis buttonCheck(timer);

    Buzzer_Init();
    setupButtons();

    while (1)
    {
        if(buttonCheck > 20){
            buttonCheck = 0;
            btnS1.tick();
        }
    }
}
