/**
 * Lab 1 — Multi-Screen Skeleton
 * ------------------------------
 * Base project for students:
 * - Two screens (LUX and MIC)
 * - Circular navigation with S1 / S2
 * - Placeholder bars and random mic level
 *
 */

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

extern "C" {
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/fpu.h"
#include "Crystalfontz128x128_ST7735.h"
#include "grlib/grlib.h"
#include "timerLib.h"
}

#include "button.h"
#include "elapsedTime.h"

// ============================================================================
// Globals
// ============================================================================
tContext gContext;
uint32_t gSysClk;
Timer timer;

Button btnLeft(S1);
Button btnRight(S2);

elapsedMillis drawTimer(timer);
elapsedMillis inputTimer(timer);

float luxValue = 0.0f;   // global shared value
float micLevel = 0.0f;   // simulated

// ============================================================================
// Screen Management
// ============================================================================
enum ScreenID { SCREEN_LUX = 0, SCREEN_MIC, SCREEN_COUNT };
uint8_t currentScreen = SCREEN_LUX;

// ============================================================================
// LCD + Header
// ============================================================================
void LCD_Init(void)
{
    Crystalfontz128x128_Init();
    Crystalfontz128x128_SetOrientation(LCD_ORIENTATION_UP);
    GrContextInit(&gContext, &g_sCrystalfontz128x128);
    GrContextFontSet(&gContext, &g_sFontFixed6x8);
}

void DrawHeader(const char *title, bool leftActive, bool rightActive)
{
    tRectangle header = {0, 0, 127, 20};
    GrContextForegroundSet(&gContext, ClrDarkBlue);
    GrRectFill(&gContext, &header);

    // Navigation arrows
    GrContextForegroundSet(&gContext, leftActive ? ClrYellow : ClrGray);
    GrStringDraw(&gContext, "<", -1, 4, 6, false);
    GrContextForegroundSet(&gContext, rightActive ? ClrYellow : ClrGray);
    GrStringDraw(&gContext, ">", -1, 118, 6, false);

    // Title centered
    GrContextForegroundSet(&gContext, ClrWhite);
    GrStringDrawCentered(&gContext, title, -1, 64, 7, false);
}

// ============================================================================
// Generic Helper — Draw a horizontal or vertical bar
// ============================================================================
void DrawBar(int x, int yTop, int yBottom, float level, bool vertical)
{
    if (level < 0) level = 0;
    if (level > 1) level = 1;

    if (vertical) {
        // Vertical bar (for mic)
        const int width = 12;
        int height = yBottom - yTop;
        int filled = (int)(height * level);
        int yStart = yBottom - filled;

        GrContextForegroundSet(&gContext, ClrGray);
        tRectangle border = {x - 2, yTop - 2, x + width + 2, yBottom + 2};
        GrRectDraw(&gContext, &border);

        GrContextForegroundSet(&gContext, ClrGreen);
        tRectangle fill = {x, yStart, x + width, yBottom};
        GrRectFill(&gContext, &fill);
    }
    else {
        // Horizontal bar (for lux)
        const int height = 10;
        int width = yBottom - yTop;
        int filled = (int)(width * level);

        GrContextForegroundSet(&gContext, ClrDarkGray);
        tRectangle bg = {x, yTop, x + width, yTop + height};
        GrRectFill(&gContext, &bg);

        GrContextForegroundSet(&gContext, ClrGreen);
        tRectangle fg = {x, yTop, x + filled, yTop + height};
        GrRectFill(&gContext, &fg);
    }
}

// ============================================================================
// Screen: Ambient Light
// ============================================================================
void ScreenLux_Draw(float lux)
{
    const float LUX_MAX = 1000.0f;
    float normalized = lux / LUX_MAX;
    if (normalized > 1.0f) normalized = 1.0f;

    tRectangle bg = {0, 21, 127, 127};
    GrContextForegroundSet(&gContext, ClrBlack);
    GrRectFill(&gContext, &bg);

    DrawHeader("Ambient Light", btnLeft.isPressed(), btnRight.isPressed());

    char buf[32];
    snprintf(buf, sizeof(buf), "%.2f lx", lux);
    GrContextForegroundSet(&gContext, ClrYellow);
    GrStringDrawCentered(&gContext, buf, -1, 64, 50, false);

    DrawBar(14, 80, 114, normalized, false);

    GrFlush(&gContext);
}

// ============================================================================
// Screen: Microphone (simulated random level)
// ============================================================================
static float fakeMicLevel()
{
    static uint32_t seed = 12345;
    seed = (1103515245 * seed + 12345) & 0x7FFFFFFF;
    return (float)(seed % 100) / 100.0f; // 0.00–0.99
}

void Draw_Mic(float level)
{
    tRectangle bg = {0, 21, 127, 127};
    GrContextForegroundSet(&gContext, ClrBlack);
    GrRectFill(&gContext, &bg);

    DrawHeader("Microphone", btnLeft.isPressed(), btnRight.isPressed());

    float fakeLevel = fakeMicLevel();
    DrawBar(58, 25, 120, fakeLevel, true);

    char buf[16];
    snprintf(buf, sizeof(buf), "%.0f %%", fakeLevel * 100.0f);
    GrContextForegroundSet(&gContext, ClrCyan);
    GrStringDrawCentered(&gContext, buf, -1, 64, 110, false);

    GrFlush(&gContext);
}

// ============================================================================
// Button callbacks (carousel navigation)
// ============================================================================
// When pressing S1 (left):
//   - Go one screen back
//   - If we're already at the first screen, wrap to the last
void OnLeftClick() {
    if (currentScreen == 0)
        currentScreen = SCREEN_COUNT - 1;
    else
        currentScreen--;
}

// When pressing S2 (right):
//   - Go one screen forward
//   - If we're already at the last, wrap to the first
void OnRightClick() {
    currentScreen++;
    if (currentScreen >= SCREEN_COUNT)
        currentScreen = 0;
}

// ============================================================================
// Main
// ============================================================================
int main(void)
{
    FPUEnable();
    FPULazyStackingEnable();
    gSysClk = SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN |
                                  SYSCTL_USE_PLL | SYSCTL_CFG_VCO_240), 120000000);

    LCD_Init();
    timer.begin(gSysClk, TIMER0_BASE);

    btnLeft.begin(); btnRight.begin();
    btnLeft.attachClick(&OnLeftClick);
    btnRight.attachClick(&OnRightClick);

    while (1)
    {
        if (inputTimer >= 10) {
            btnLeft.tick();
            btnRight.tick();
            inputTimer = 0;
        }

        if (drawTimer >= 50) {
            switch (currentScreen) {
                case SCREEN_LUX:
                    ScreenLux_Draw(luxValue);
                    break;
                case SCREEN_MIC:
                    Draw_Mic(micLevel);
                    break;
            }
            drawTimer = 0;
        }
    }
}
